#!/bin/bash
set -x

if [ $# -lt 3 ]; then
  echo "usage: deploy.sh <awscliprofile> <region> <environment> [<buildId>]";
  exit 1;
fi

CFN_YAML="cfn.yml";
AWS_CLI_PROFILE="$1";
REGION="$2";
ENV="$3";
BUILDID="$4";
APP_NAME="accountsbrilliongea"
APP_NAME_ENV="${APP_NAME}-${ENV}"

if [ -z "$WORKSPACE" ]; then
  WORKSPACE=".";
fi

# Login to ECR
$(aws ecr get-login --no-include-email --region us-east-1)

# Build the image
docker build -t $APP_NAME_ENV .

# Tag the image
docker tag ${APP_NAME_ENV}:latest 070913506331.dkr.ecr.us-east-1.amazonaws.com/${APP_NAME_ENV}:latest

# Push the image
docker push 070913506331.dkr.ecr.us-east-1.amazonaws.com/${APP_NAME_ENV}:latest

# Remove the local image
docker rmi ${APP_NAME_ENV}:latest

# Copy cloudformation to S3
S3_CFN=wca-s3-artifacts-$REGION/cfn/$APP_NAME/$ENV/cfn-$REGION-$BUILDID.yml

aws s3 cp \
--region $REGION \
--profile $AWS_CLI_PROFILE \
 $WORKSPACE/$CFN_YAML s3://$S3_CFN

# Validate cloudformation
aws cloudformation validate-template \
--region $REGION \
--profile $AWS_CLI_PROFILE \
--template-url http://s3.amazonaws.com/$S3_CFN

if [ $? -gt 0 ]; then
 exit 225;
fi

aws cloudformation describe-stacks \
--region $REGION \
--profile $AWS_CLI_PROFILE \
--stack-name $APP_NAME_ENV

if [ $? -eq 0 ]; then
    # The stack is deployed, hopefully the service has been created...
    # Now, trigger a new deployment

    aws ecs --region $REGION --profile $AWS_CLI_PROFILE \
    update-service --cluster wca-fargate --service $APP_NAME_ENV \
    --force-new-deployment

    #aws cloudformation update-stack \
    #--region $REGION \
    #--profile $AWS_CLI_PROFILE \
    #--stack-name $APP_NAME_ENV \
    #--template-url http://s3.amazonaws.com/$S3_CFN \
    #--capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM
else
    aws cloudformation create-stack \
    --region $REGION \
    --profile $AWS_CLI_PROFILE \
    --stack-name $APP_NAME_ENV \
    --template-url http://s3.amazonaws.com/$S3_CFN \
    --capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM
fi